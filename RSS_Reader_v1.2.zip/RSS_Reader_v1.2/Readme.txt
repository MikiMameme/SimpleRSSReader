【RSSリーダー】

■起動方法
RSS_Reader_v1.2.exe をダブルクリックしてください。
初回起動時はフィードがありませんので画面に従いRSSフィードを登録してください。
二回目以降の起動からはfeeds.jsonというファイルよりフィード情報を読み込みます、追加や削除も行うことができます。

■フォントについて
このアプリには Google Fonts の Noto Sans JP を同梱（埋め込み）しています。
(SIL Open Font License 1.1)

■保存データについて
追加したフィード情報は、同じフォルダ内の feeds.json に保存されます。

■このアプリについて
私（K.N）のプログラミング学習で作った成果物です。
なお、作成にあたりGeminiやClaudeなど生成AIとの協力により作られています。

■注意事項
このプログラムは細心の注意をもって作られていますが、万が一このプログラムを使用したことによる損害などの責任は一切負いません。

■ライセンス
プログラムのライセンスはMITライセンスです。詳しくはLICENSEをご覧ください。

■更新履歴
1.0
　公開

1.1
　使いやすくするために並び順を「新→旧」または「旧→新」と変えられるようにした。

1.2
　以下の機能を追加した。

　・既読管理システム（Read.json）
　記事のタイトルをクリックすると、その記事の「ユニークなURL」が保存、次回以降の表示が自動的にグレーアウト（灰色）され視覚的にわかりやすくした。
　read.json に履歴として保存、既読状態が維持される。

　・検索機能
　記事一覧の右上に検索バーを追加。
　絞り込み: 入力した文字が含まれる記事だけを表示。
　対象範囲: タイトルだけでなく、記事の説明文からも検索。

　・日時表示の改善
　一覧と詳細画面の両方に、記事の公開日時（YYYY/MM/DD HH:MM 形式）を表示するようにした。



■付録

【feeds.jsonの構造】

　{
  "feeds": [
    {
      "name": "名前A",
      "url": "https://example.co.jp/data/rss/feeds.xml"
    },
    {
      "name": "名前B",
      "url": "https://news.example.co.jp/rss/topics/feeds.xml"
    }
  ]
}

　
【Read.jsonの構造】

　[
  "https://example.com/news/article_01.html",
  "https://exampleblog.jp/posts/12345",
  "https://exampletech-news.net/entry/rust-update"
]
