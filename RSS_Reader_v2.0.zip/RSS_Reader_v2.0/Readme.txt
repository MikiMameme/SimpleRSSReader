【RSSリーダー Ver 2.0】

■概要
Rust言語で作成された、デスクトップ版RSSリーダーです。
登録したニュースフィードの取得・閲覧に加え、VOICEVOXを利用した「記事の読み上げ機能」を搭載しました。

■起動方法
RSS_Reader.exe をダブルクリックしてください。

【初回起動時】
1. 左側のフィードの「＋追加」よりRSSフィードを登録してください。
2. 音声読み上げ機能を利用する場合は、左パネルの「VOICEVOX起動設定」から設定を行います。

■VOICEVOX連携機能について
このアプリは、無料の音声合成ソフト「VOICEVOX」と連携して記事を読み上げます。

連携を使わない方法でも読み上げ機能を使用できます。
先にVOICEVOXを起動し、次にRSS_Reader.exeを起動してください。

1. **連携設定**: 
   左パネルの「VOICEVOX起動設定」にあるフォルダアイコン（📂）をクリックし、お使いのPCにインストールされているVOICEVOXの実行ファイル（VOICEVOX.exe）を選択してください。

2. **アプリからの起動**: 
   設定後、VOICEVOXが起動していない状態で「🚀 アプリから起動する」ボタンを押すと、このアプリから直接VOICEVOXを起動できます。

3. **再接続**: 
   VOICEVOXの起動完了後、接続ステータスが「🔴 未接続」のままの場合は「再接続」ボタンを押してください。

■主な機能
・**記事の閲覧**: 登録したRSSフィードから最新記事を取得します。
・**音声読み上げ**: 選択した記事、または新着記事を連続で読み上げます。
・**自動巡回**: 指定した間隔でニュースをチェックし、新着があれば音声でお知らせします。
・**既読管理**: 一度クリックした記事はタイトルがグレーアウトされます。
・**検索機能**: タイトルや本文からキーワード検索が可能です。

■動作環境
（RSSリーダーとして使う場合）
・Windows 10 / 11 が正常に動作し、インターネット接続されたパソコン

（VOICEVOX読み上げ機能を使う場合）
・VOICEVOXが快適に動作するスペック
  （例：4コア以上のCPUや、GPUが搭載されているPCなど）
・VOICEVOX（別途インストールが必要です）
  公式サイト: https://voicevox.hiroshiba.jp/

■保存データについて
以下のファイルが自動生成・更新されます。
・feeds.json : 登録したRSSフィード情報
・read.json  : 既読記事の履歴
・settings.json : アプリの設定（話者設定やVOICEVOXのパスなど）

■フォントについて
Google Fonts の Noto Sans JP を同梱（埋め込み）しています。
(SIL Open Font License 1.1)

■開発について
私（K.N）のプログラミング学習で作った成果物です。
なお、作成にあたりGeminiやClaudeなど生成AIとの協力により作られています。

■免責事項
このプログラムは細心の注意をもって作られていますが、万が一このプログラムを使用したことによる損害などの責任は一切負いません。

■ライセンス
MIT Licenseです。詳しくはLICENSEをご覧ください。

■更新履歴
2.0
　・VOICEVOX連携機能の実装
　　（読み上げ、アプリ内からの起動、設定機能の追加）
　・自動巡回機能の追加
　・UIの調整

1.2
　・既読管理システムの追加
　・検索機能、日時表示の改善

1.1
　・並び順変更機能の追加

1.0
　・公開


■付録

【feeds.jsonの構造】

　{
  "feeds": [
    {
      "name": "名前A",
      "url": "https://example.co.jp/data/rss/feeds.xml"
    },
    {
      "name": "名前B",
      "url": "https://news.example.co.jp/rss/topics/feeds.xml"
    }
  ]
}

　
【Read.jsonの構造】

　[
  "https://example.com/news/article_01.html",
  "https://exampleblog.jp/posts/12345",
  "https://exampletech-news.net/entry/rust-update"
]


【settings.jsonの構造】

※話者をずんだもんに設定し、VOICEVOXのパスを指定した際の例
 {
  "speaker_name": "ずんだもん",
  "style_id": 3,
  "speed": 1.0,
  "timer_enabled": false,
  "timer_interval_min": 30,
  "right_panel_width": 400.0,
  "voicevox_path": "C:\\Users\\user\\AppData\\Local\\Programs\\VOICEVOX\\VOICEVOX.exe" 
}


